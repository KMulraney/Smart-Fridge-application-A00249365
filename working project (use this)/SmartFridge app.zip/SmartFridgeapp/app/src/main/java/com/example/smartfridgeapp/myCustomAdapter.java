package com.example.smartfridgeapp;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.util.List;

public class myCustomAdapter extends ArrayAdapter<itemsInFridge> {


    Context context;

    List<itemsInFridge> List;
    public myCustomAdapter(@NonNull Context context, List<itemsInFridge> quoteList) {
        super(context, 0, quoteList);
        this.List=quoteList;
        this.context=context;

    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {

        //create view
        View view  = convertView;
        if(view == null){
            view = LayoutInflater.from(context).inflate(R.layout.listview,parent,false);
        }

        itemsInFridge items = List.get(position);


        TextView textview = view.findViewById(R.id.list_row_tv);
        textview.setText(items.toString());

        return view;



    }
}
