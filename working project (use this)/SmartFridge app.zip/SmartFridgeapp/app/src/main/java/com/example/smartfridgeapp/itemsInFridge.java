package com.example.smartfridgeapp;

import org.w3c.dom.Node;

public class itemsInFridge {
    public String barcode;
    public  String name;
    public  Double weight;
    public long time;

    public itemsInFridge(){

    }
    public itemsInFridge(String bar,String name, Double weight, Long time) {
        this.barcode=bar;
        this.name=name;
        this.weight= weight;
        this.time=time;
    }

    public long getTime() {
        return time;
    }
    public String getBarcode() {
        return barcode;
    }

    public String getName() {
        return name;
    }

    public Double getWeight() {
        return weight;
    }

    public void setBarcode(String barcode) {
        this.barcode = barcode;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setWeight(Double weight) {
        this.weight = weight;
    }

    public void setTime(long time) {
        this.time = time;
    }

    @Override
    public String toString() {
        return "item{" +
                "barcode='" + barcode + '\'' +
                ", name='" + name + '\'' +
                ", weight=" + weight +
                '}';
    }


}
