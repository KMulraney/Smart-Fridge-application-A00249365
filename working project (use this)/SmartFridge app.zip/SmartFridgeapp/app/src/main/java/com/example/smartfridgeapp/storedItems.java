package com.example.smartfridgeapp;

import org.w3c.dom.Node;

public class storedItems {

    public String barcode;
    public String name;
    public Double weight;


    public storedItems(){

    }
    public storedItems(String bar,String name, Double weight) {
        this.barcode=bar;
        this.name=name;
        this.weight= weight;
    }

    public String readBarcode(){
        return barcode;
    }
    public String readName() {
        return name;
    }
    public Double readWeight() {
        return weight;
    }

    public void setBarcode(String barcode) {
        this.barcode = barcode;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setWeight(Double weight) {
        this.weight = weight;
    }

    @Override
    public String toString() {
        return "item{" +
                "barcode='" + barcode + '\'' +
                ", name='" + name + '\'' +
                ", weight=" + weight +
                '}';
    }
}
