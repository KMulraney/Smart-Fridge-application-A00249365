package com.example.smartfridgeapp;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Arrays;
import java.util.Calendar;

import com.budiyev.android.codescanner.CodeScanner;
import com.budiyev.android.codescanner.ScanMode;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.textfield.TextInputEditText;

import org.eclipse.paho.android.service.MqttAndroidClient;
import org.eclipse.paho.client.mqttv3.DisconnectedBufferOptions;
import org.eclipse.paho.client.mqttv3.IMqttActionListener;
import org.eclipse.paho.client.mqttv3.IMqttDeliveryToken;
import org.eclipse.paho.client.mqttv3.IMqttToken;
import org.eclipse.paho.client.mqttv3.MqttCallback;
import org.eclipse.paho.client.mqttv3.MqttCallbackExtended;
import org.eclipse.paho.client.mqttv3.MqttClient;
import org.eclipse.paho.client.mqttv3.MqttConnectOptions;
import org.eclipse.paho.client.mqttv3.MqttException;
import org.eclipse.paho.client.mqttv3.MqttMessage;
import org.eclipse.paho.client.mqttv3.persist.MemoryPersistence;
import org.w3c.dom.Node;

import java.lang.reflect.Type;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.Random;
import java.util.Date;

import com.budiyev.android.codescanner.CodeScanner;
import com.budiyev.android.codescanner.CodeScannerView;
import com.budiyev.android.codescanner.DecodeCallback;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.google.zxing.Result;

import static com.budiyev.android.codescanner.ScanMode.CONTINUOUS;


public class MainActivity extends AppCompatActivity implements MqttCallbackExtended {
    public final static String TAG = "DebugMQTT";
    //private String broker = "tcp://maqiatto.com:1883";
    private String broker = "tcp://broker.hivemq.com:1883";
    private String clientId;
    private String topic = "bookedartifact9@gmail.com/smartfridge";
    private int flag = 0;
    private int bootFlag=0;

//    private String username= "bookedartifact9@gmail.com";
//    private String Password ="12360";

    private TextView textView;
    private TextView textView123;
    private Button addItem;
    private TextInputEditText barcode;
    private TextInputEditText name;
    private TextInputEditText weight;
    private ListView lv;
    private TextView TotalWeightTV;

    private itemsInFridge ItemsInFridge;
    private ArrayList<itemsInFridge> list = new ArrayList<itemsInFridge>();

    private ArrayList<storedItems> storedList = new ArrayList<storedItems>();

    private Double weightIn =0.0;
    private Double newWeight = 0.0;
    private Double totalweight=0.0;
    private int checkingFlag =0;

    private CodeScanner codeScanner;
    private  myCustomAdapter adapter;

    private MqttAndroidClient mqttAndroidClient;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        CodeScannerView scannerView = findViewById(R.id.scanner_view);
        ScanMode scanMode;
        codeScanner = new CodeScanner(this, scannerView);
        codeScanner.setScanMode(CONTINUOUS);
        addItem = findViewById(R.id.add);
        barcode = findViewById(R.id.barcode);
        TotalWeightTV = findViewById(R.id.TotalWeightTV);
        name = findViewById(R.id.name);
        weight = findViewById(R.id.weight);
        lv = findViewById(R.id.listview);

        adapter = new myCustomAdapter(this,list);
        lv.setAdapter(adapter);


        // Initialize Firebase Auth
        FirebaseAuth mAuth = FirebaseAuth.getInstance();
        // Check if user is signed in (non-null) and update UI accordingly.
        FirebaseUser currentUser = mAuth.getCurrentUser();
        if(currentUser == null){
            mAuth.signInAnonymously()
                    .addOnCompleteListener(this, new OnCompleteListener<AuthResult>() {
                        @Override
                        public void onComplete(@NonNull Task<AuthResult> task) {
                            if (task.isSuccessful()) {
                                // Sign in success, update UI with the signed-in user's information
                                Log.d(TAG, "signInAnonymously:success");
                                FirebaseUser user = mAuth.getCurrentUser();
                                updateUI(user);
                            } else {
                                // If sign in fails, display a message to the user.
                                Log.w(TAG, "signInAnonymously:failure", task.getException());
                                Toast.makeText(MainActivity.this, "Authentication failed.", Toast.LENGTH_SHORT).show();
                                updateUI(null);
                            }
                        }
                    });
        }else{
            updateUI(currentUser);
        }


        FirebaseDatabase database = FirebaseDatabase.getInstance();
        DatabaseReference databaseReference = database.getReference();
        databaseReference.child("Fridge").addValueEventListener(new ValueEventListener() {

            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                // get all of the children at this level.

                Iterable<DataSnapshot> children = dataSnapshot.getChildren();

                list.clear();
                // shake hands with each of them.'
                for (DataSnapshot child : children) {
                    itemsInFridge value = child.getValue(itemsInFridge.class);
                    if(bootFlag==0){
                    list.add(value);}
                    else if (bootFlag >0){

                        list.add(value);
                        adapter.notifyDataSetChanged();
                    }
                    bootFlag++;
                }
                adapter.notifyDataSetChanged();

            }

            @Override
            public void onCancelled(DatabaseError databaseError) {

            }
        });
        databaseReference.child("Stored").addValueEventListener(new ValueEventListener() {

            /**
             * This method will be invoked any time the data on the database changes.
             * Additionally, it will be invoked as soon as we connect the listener, so that we can get an initial snapshot of the data on the database.
             * @param dataSnapshot
             */
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                // get all of the children at this level.
                Iterable<DataSnapshot> children = dataSnapshot.getChildren();

                // shake hands with each of them.'
                for (DataSnapshot child : children) {
                    storedItems ItemsInFridge = child.getValue(storedItems.class);
                    storedList.add(ItemsInFridge);

                }



            }

            @Override
            public void onCancelled(DatabaseError databaseError) {

            }
        });

        textView = findViewById(R.id.textView);
        if (ContextCompat.checkSelfPermission(MainActivity.this, Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(MainActivity.this, new String[]{Manifest.permission.CAMERA}, 100);

        }
        codeScanner.setDecodeCallback(new DecodeCallback() {
            @Override
            public void onDecoded(@NonNull final Result result) {
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        Toast.makeText(MainActivity.this, result.getText(), Toast.LENGTH_SHORT).show();
                        barcode.setText(result.getText());
                        //TODO add a check if the scanned item is available and toast this to the user
                        int i=0;

                        while(i<storedList.size()) {
                            storedItems checking= storedList.get(i);
                            if (barcode.getText().toString().equals(checking.readBarcode())){
                                Toast.makeText(MainActivity.this, "item found", Toast.LENGTH_SHORT).show();
                                checkingFlag++;
                            }
                            i++;
                        }
                        if(checkingFlag==0){
                            Toast.makeText(MainActivity.this, "item not found", Toast.LENGTH_SHORT).show();

                        }
                        checkingFlag=0;

                        return;
                    }
                });
            }
        });

        mqttConnect();

        addItem.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int i=0;

                while(i<storedList.size()) {
                    storedItems checking= storedList.get(i);
                    if (barcode.getText().toString().equals(checking.readBarcode())){
                        publishList(checking.readBarcode(),checking.readName(),checking.readWeight().toString());
                        checkingFlag++;
                        break;
                    }
                    i++;
                }

                if(checkingFlag==0){
                    publishedStoredList(barcode.getText().toString(),name.getText().toString(),weight.getText().toString());

                    publishList(barcode.getText().toString(),name.getText().toString(),weight.getText().toString());

                }

                checkingFlag=0;

                lv.setOnItemClickListener(new AdapterView.OnItemClickListener()
                {
                    public void onItemClick(AdapterView<?> arg0, View arg1,int arg2, long arg3)
                    {
                        DatabaseReference ref = FirebaseDatabase.getInstance().getReference();
                        Query fridgeQuery = ref.child("Fridge").orderByChild("time").equalTo(list.get(arg2).getTime());

                        fridgeQuery.addListenerForSingleValueEvent(new ValueEventListener() {
                            @Override
                            public void onDataChange(DataSnapshot dataSnapshot) {
                                for (DataSnapshot appleSnapshot: dataSnapshot.getChildren()) {
                                    appleSnapshot.getRef().removeValue();
                                    adapter.notifyDataSetChanged();
                                }
                            }

                            @Override
                            public void onCancelled(DatabaseError databaseError) {
                                Log.e(TAG, "onCancelled", databaseError.toException());
                            }
                        });

                        adapter.notifyDataSetChanged();
                    }
                });

                weight.setText("");
                name.setText("");
                barcode.setText("");
            }
        });



    }

    private void updateUI(FirebaseUser user) {
    }


    private void publishList(String barcode, String name, String weight ){
       Date date = new Date();
        itemsInFridge items =  new itemsInFridge();
        items.setBarcode(barcode);
        items.setName(name);
        items.setWeight(Double.parseDouble(weight));
        items.setTime(date.getTime());

        try {

            FirebaseDatabase database = FirebaseDatabase.getInstance();
            DatabaseReference databaseReference = database.getReference();
            databaseReference.child("Fridge").push().setValue(items);

        } catch (Exception e) {
            e.printStackTrace();
        }


    }

    private void publishedStoredList(String barcode, String name, String weight){

        storedItems sitems =  new storedItems();
        sitems.setBarcode(barcode);
        sitems.setName(name);
        sitems.setWeight(Double.parseDouble(weight));

        try {

            FirebaseDatabase database = FirebaseDatabase.getInstance();
            DatabaseReference databaseReference = database.getReference();
            databaseReference.child("Stored").push().setValue(sitems);

        } catch (Exception e) {
            e.printStackTrace();
        }


    }


    private void mqttConnect() {
        try {
            clientId = MqttClient.generateClientId();  // set randomly generated client identifier

            mqttAndroidClient = new MqttAndroidClient(this, broker, clientId); // MqttAndroidClient that can be used to communicate with an MQTT server
            mqttAndroidClient.setCallback(this); // Sets a callback listener to use for events such as : new message arrived,connection has been lost,..

            MqttConnectOptions connOpts = new MqttConnectOptions();
            connOpts.setMqttVersion(MqttConnectOptions.MQTT_VERSION_3_1);
            connOpts.setAutomaticReconnect(true);
            connOpts.setCleanSession(true);
            connOpts.setConnectionTimeout(3);
            connOpts.setKeepAliveInterval(60);
//            connOpts.setPassword(Password.toCharArray());
//            connOpts.setUserName(username);

            Log.d(TAG, "Connecting to broker: " + broker);

            mqttAndroidClient.connect(connOpts, null, new IMqttActionListener() {

                @Override
                public void onSuccess(IMqttToken asyncActionToken) {

                    //DisconnectedBufferOptions holds the set of options that govern the behaviour of Offline (or Disconnected) buffering of messages
                    DisconnectedBufferOptions disconnectedBufferOptions = new DisconnectedBufferOptions();
                    disconnectedBufferOptions.setBufferEnabled(true);
                    disconnectedBufferOptions.setBufferSize(100);
                    disconnectedBufferOptions.setPersistBuffer(false);
                    disconnectedBufferOptions.setDeleteOldestMessages(false);
                    mqttAndroidClient.setBufferOpts(disconnectedBufferOptions);

                    Log.d(TAG, "onSuccess: Connected");
                    Toast.makeText(MainActivity.this, "Connected", Toast.LENGTH_SHORT).show();

                    subscribe(topic);
                }

                @Override
                public void onFailure(IMqttToken asyncActionToken, Throwable exception) {
                    Log.e(TAG, "onFailure: " + exception.getMessage(),exception);
                }
            });



        } catch (MqttException me) {
            Log.e(TAG, "msg " + me.getMessage());
            me.printStackTrace();

            Toast.makeText(MainActivity.this, "not Connected", Toast.LENGTH_SHORT).show();
        }
    }

    private void subscribe(String topic) {
        try {
            mqttAndroidClient.subscribe(topic, 0, null, new IMqttActionListener() {
                @Override
                public void onSuccess(IMqttToken asyncActionToken) {
                    Log.d(TAG, "onSuccess subscribed to : "+topic);
                }

                @Override
                public void onFailure(IMqttToken asyncActionToken, Throwable exception) {
                    Log.e(TAG, "onFailure subscribing to : "+exception.getMessage(),exception);
                }
            });
        } catch (MqttException ex) {
            Log.e(TAG, "subscribe: "+ex.getMessage(),ex);
            ex.printStackTrace();
        }
    }

    @Override
    public void connectionLost(Throwable cause) {
        Log.d(TAG, cause.getMessage());
    }


    public void messageArrived(String topic1, MqttMessage message) throws Exception {
        final String incomingMessage = new String(message.getPayload());
        Log.d(TAG, incomingMessage);
        weightIn= Double.parseDouble(incomingMessage);
        if (topic1.equals(topic)) {
            textView.setText(incomingMessage);
        }

        if(flag==0){
            newWeight = weightIn;
            totalweight= weightIn;
            flag++;
        } else if (flag==1){
            newWeight = weightIn - newWeight;
        }

        if(weightIn>totalweight){
            totalweight=weightIn;
        }else if (weightIn<totalweight){
            Double sizeOfItemRemoved = totalweight-weightIn;

            Log.d(TAG, "size of item removed " + sizeOfItemRemoved);

            for(itemsInFridge item : list){

                if(Double.compare(item.getWeight(), sizeOfItemRemoved) == 0){

                    Log.d(TAG, "inside while if");

                    DatabaseReference ref = FirebaseDatabase.getInstance().getReference();
                    Query fridgeQuery = ref.child("Fridge").orderByChild("time").equalTo(item.getTime());

                    fridgeQuery.addListenerForSingleValueEvent(new ValueEventListener() {
                        @Override
                        public void onDataChange(DataSnapshot dataSnapshot) {

                            for (DataSnapshot appleSnapshot: dataSnapshot.getChildren()) {
                                appleSnapshot.getRef().removeValue();
                                adapter.notifyDataSetChanged();
                            }
                        }

                        @Override
                        public void onCancelled(DatabaseError databaseError) {
                            Log.e(TAG, "onCancelled", databaseError.toException());
                        }
                    });
                    adapter.notifyDataSetChanged();
                    break;
                }
            }
            // update total weight with current (reset)
            totalweight=weightIn;

        }

        if(newWeight>0) {
            weight.setText(newWeight.toString());
        }
        Log.d(TAG, "messageArrived: "+totalweight);
        TotalWeightTV.setText(totalweight.toString());
        newWeight=weightIn;


    }



    @Override
    public void deliveryComplete(IMqttDeliveryToken token) {

    }


    @Override
    protected void onPause() {
        super.onPause();
        codeScanner.releaseResources();
        try {
            mqttAndroidClient.unregisterResources();
            mqttAndroidClient.disconnect();
            mqttAndroidClient = null;
        } catch (MqttException e) {
            e.printStackTrace();
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        codeScanner.startPreview();
        if (mqttAndroidClient == null) {
            mqttConnect();
        }
    }


    @Override
    public void connectComplete(boolean reconnect, String serverURI) {

    }
}